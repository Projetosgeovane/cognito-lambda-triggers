import { Module } from '@nestjs/common';
import { CustomMessageModule } from './handlers/custom-message/custom-message.module';
import { DefineAuthChallengeModule } from './handlers/define-auth-challenge/define-auth-challenge.module';
import { CreateAuthChallengeModule } from './handlers/create-auth-challenge/create-auth-challenge.module';
import { PreSignUpModule } from './handlers/pre-sing-up/pre-sign-up.module';
import { VerifyAuthChallengeModule } from './handlers/verify-auth-challenge/verify-auth-challenge.module';

@Module({
  imports: [
    PreSignUpModule,
    CustomMessageModule,
    DefineAuthChallengeModule,
    CreateAuthChallengeModule,
    VerifyAuthChallengeModule,
  ],
})
export class AppModule {}
